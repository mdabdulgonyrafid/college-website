<?php
$db=mysqli_connect('localhost','root','','collage');
if($db){

}else{
echo 'Connection Error';
}
?>