<?php
include('php/con.php');
session_start();
if(isset($_SESSION['uuid'])){
$sess=$_SESSION['uuid'];
}

?>
<html>
<head>
<title>Govt. Ispahani Collage</title>
<meta lang="en">
 <link href="site/l.png" rel="icon">
  <link href="site/l.png" rel="apple-touch-icon">
  <link href = 'https://fonts.googleapis.com/icon?family=Material+Icons' rel = 'stylesheet'>
 <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.css" rel="stylesheet">
<meta name="author" content="Govt Ispahani Collage">
<meta charset="UTF-8">
  <meta name="description" content="Welcome to the Govt Ispahani Collage Website. Stay connected with us for getting notices and more information.">
  <meta name="keywords" content="Collage, Govt Collage, Ispahani Collage, Govt Ispahani Collage">
	<meta name="viewport" content="width=device-width, initial-scale=1 user-scalable=no">
	<script src="javascript/date.js"></script>
<script src="j.avascript/slider.js"></script>
<style>
@font-face{
font-family:'en';
src: url('fonts/english.ttf');
}
@font-face{
font-family:'bn';
src: url('fonts/bangla.ttf');
}
body{
margin:0;
padding:0;
font-family: 'en';
//background: url('site/clg.jpg') no-repeat;
}
.navBar{
overflow: hidden;
  background-color:#fff;
  position: fixed;
  bottom:0;
  width: 100%;
  
  
}
.navBar span{
border-right:1px solid black;
margin-left:50px;
padding-right:20px;
}
.bodyContent{
height:1500px;
width:100%;
margin:0;
padding-top:70px;
margin-bottom: 1500px;
}
.headerContent{
//border-bottom:1px solid rgba(0,0,0,.5);
position: fixed;
overflow: hidden;
top:0;
width:100%;
background: #fff;
color: #fff;
box-shadow: 0px 03px 12px 0px #000;
}
.logo{
width:240px;
height:80px;
}
.pinMenu{
height: 35px;
width: 35px;
float: right;
margin-right:20px;
margin-top: 25px;
border: 1px solid rgba(0,0,0,.2);
}
 .navBar img{
height: 40px;
width: 40px;
margin-right: 32px;

}
.pinHome{
padding-left:15px;
}
.tableHome{
padding-left:15px;
}
@media screen and (min-width: 500px) {
         .navBar img{
height: 40px;
width: 40px;
margin-right: 70px;

}
.pinHome{
padding-left:40px;

}
.tableHome{
padding-left:40px;

}
.headLine{
border:2px solid #fff;
width: 80%;
margin: 0px 0px 0px 60px;
margin-bottom:20px;
padding: 5px;
background: #4ACBD6;
}

      }

table tr td{
font-weight: bold;
color:rgba(0,0,0,.7)
}

      
     
   .lightbox {
         display: table; /* helps us center the lightbox-content */
         /* make the lightbox occupy the entire page */
         position: fixed;
         top: -100%; /* position the lightbox above the top edge */
         right: 0;
         width: 70%;
         height: 100%;
         background: #fff; /* black with 0.7 opacity */
         transition-duration: 0.5s; /* set the duration of the slide down effect */
      }
      .lightbox:target {
         top: 0; /* cover the entire screen */
      }
      .lightbox-content {
          /* vertically center */
         margin-top:50px;
         text-align: center;
       /* horizontally center */
       color: rgba(0,0,0,.7);
      }
      .close {
         /* position the CLOSE button to the top-right corner */
         position: absolute;
         top: 10px;
         right: 10px;
         color: black;
         
         /* style the close button */
         font-size: 20px;
         font-weight: 300;
         text-decoration: none;
         
      }
      
      /* make the image responsive */
      img {
         max-width: 100%;
         height: auto;
      }
 hr{
 
margin-left:19px;
margin-right:19px;

 }
.dateTime{
float: left;
margin-left: 15px;
font-weight: bold;
font-size: 16px;
}
@media screen and (min-width: 500px) {
    
    .dateTime{
float: left;
margin-left: 15px;
font-weight: bold;
font-size: 20px;
}

}
.headLine{
border:2px solid #fff;
width: 80%;
margin: 0px 0px 0px 30px;
margin-bottom:20px;
padding: 5px;
background: #4ACBD6;
}


@media screen and (min-width: 500px) {
    
.headLine{
border:2px solid #fff;
width: 80%;
margin: 0px 0px 0px 60px;
margin-bottom:20px;
padding: 5px;
background: #4ACBD6;
}

      }



.headLine span{
font-size: 18px;

}
marquee{
padding-right: 150px;
background: #fff;
padding: 3px;
color: #000;
}
.headSpan{
background: #4ACBD6;
color: #fff;
padding-right: 5px;
}
.headMar{
background: #fff;
}

.partOne{
//background: rgba(168,228,192,.7);
}
.headAbout{


color: #fff;
font-size: 25px;
padding-left: 10px;
margin: 0px 05px 0px 05px;
background: #4ACBD6;
border-radius: 5px;
}
.about{
padding-left: 10px;
}
@media screen and (min-width: 500px) {
    
.headAbout{

color: #fff;
font-size: 25px;
padding-left: 10px;
margin: 0px 05px 0px 05px;
background: #4ACBD6;
border-radius: 5px;
}


      }
      

.slider{
height: 220px;

}

@media screen and (min-width: 500px) {
    

 .slider{
height: 400px;

}
 
      }
.footer{
width:100%;
background-color: rgba(59,68,75,.9);
margin: 0;
color: #fff;
margin: 0px 0px 0px 0px;
font-family: arial;
}
.boxF{
float: ;
width: 100%;
border-right: 2px solid #fff;
margin: 05px 0px 0px 0px;
font-family: arial;
}
h2{
font-size: 20px;
}

@media screen and (min-width: 500px) {
    

.footer{
width:100%;
background-color: rgba(59,68,75,.9);
margin: 0;
color: #fff;
margin: 0px 0px 0px 0px;
font-family: arial;
}
.boxF{
width: 100%;
border-right: 2px solid #fff;
margin: 05px 0px 0px 0px;
font-family: arial;
}
h2{

}
 
      }
      
    
@media screen and (min-width: 500px) {
    
.bodyContent{
height:1800px;
width:100%;
margin:0;
padding-top:70px;
margin-bottom: 1500px;
}

 
      }
 .deve{
 width: 100%;
 height: 50px;
 background-color: #280F36;
 color: #fff;
 font-family: verdana;
 padding-top: 20px;
 

 }

.mujib img{
width: 40%;
height: auto;
margin-left: 20px;

}
.prof{

}
.prof img{
height: 320px;
width: 300px;
}
.pro{
color: #fff;
font-size: 25px;
padding-left: 10px;
margin: 0px 05px 0px 05px;
background: #4ACBD6;
border-radius: 5px;
}
.namePlate{
margin-left: 20px;
}


ul {
    margin: 0px;
    padding: 0px;
}
.footer-section {
  background: #151414;
  position: relative;
}
.footer-cta {
  border-bottom: 1px solid #373636;
}
.single-cta i {
  color: #ff5e14;
  font-size: 30px;
  float: left;
  margin-top: 8px;
}
.cta-text {
  padding-left: 15px;
  display: inline-block;
}
.cta-text h4 {
  color: #fff;
  font-size: 20px;
  font-weight: 600;
  margin-bottom: 2px;
}
.cta-text span {
  color: #757575;
  font-size: 15px;
}
.footer-content {
  position: relative;
  z-index: 2;
}
.footer-pattern img {
  position: absolute;
  top: 0;
  left: 0;
  height: 330px;
  background-size: cover;
  background-position: 100% 100%;
}
.footer-logo {
  margin-bottom: 30px;
}
.footer-logo img {
    max-width: 200px;
}
.footer-text p {
  margin-bottom: 14px;
  font-size: 14px;
      color: #7e7e7e;
  line-height: 28px;
}
.footer-social-icon span {
  color: #fff;
  display: block;
  font-size: 20px;
  font-weight: 700;
  font-family: 'Poppins', sans-serif;
  margin-bottom: 20px;
}
.footer-social-icon a {
  color: #fff;
  font-size: 16px;
  margin-right: 15px;
}
.footer-social-icon i {
  height: 40px;
  width: 40px;
  text-align: center;
  line-height: 38px;
  border-radius: 50%;
}
.facebook-bg{
  background: #3B5998;
}
.twitter-bg{
  background: #55ACEE;
}
.google-bg{
  background: #DD4B39;
}
.footer-widget-heading h3 {
  color: #fff;
  font-size: 20px;
  font-weight: 600;
  margin-bottom: 40px;
  position: relative;
}
.footer-widget-heading h3::before {
  content: "";
  position: absolute;
  left: 0;
  bottom: -15px;
  height: 2px;
  width: 50px;
  background: #ff5e14;
}
.footer-widget ul li {
  display: inline-block;
  float: left;
  width: 50%;
  margin-bottom: 12px;
}
.footer-widget ul li a:hover{
  color: #ff5e14;
}
.footer-widget ul li a {
  color: #878787;
  text-transform: capitalize;
}
.subscribe-form {
  position: relative;
  overflow: hidden;
}
.subscribe-form input {
  width: 100%;
  padding: 14px 28px;
  background: #2E2E2E;
  border: 1px solid #2E2E2E;
  color: #fff;
}
.subscribe-form button {
    position: absolute;
    right: 0;
    background: #ff5e14;
    padding: 13px 20px;
    border: 1px solid #ff5e14;
    top: 0;
}
.subscribe-form button i {
  color: #fff;
  font-size: 22px;
  transform: rotate(-6deg);
}
.copyright-area{
  background: #202020;
  padding: 25px 0;
}
.copyright-text p {
  margin: 0;
  font-size: 14px;
  color: #878787;
}
.copyright-text p a{
  color: #ff5e14;
}
.footer-menu li {
  display: inline-block;
  margin-left: 20px;
}
.footer-menu li:hover a{
  color: #ff5e14;
}
.footer-menu li a {
  font-size: 14px;
  color: #878787;
}
.lightbox a{

text-decoration: none;
}
</style>
</head>
<body>
			<div class="bodyContent">
		<div class="headerContent">
	<img class="logo" src="site/logo.png"/>

	<a href="#example"><img class="pinMenu" src="pinch/menu.png"/></a>
   
	</div>


			<div class="lightbox" id="example">
   	   <a href="#" class="close"><img src="pinch/close.png" style="height:20px;width:20px;"/></a>
   	   <br>
   	   
   	   <h2 style="margin-left:10px">বিভাগ সমুহের লিংক</h2>
   	   
     		 <div class="lightbox-content">
       
  <a href="islamic-history-and-cultural-section/">     ইসলাম ইতিহাস ও সংস্কৃতি বিভাগ</a>
<hr>
<a href="#">সমাজবিজ্ঞান বিভাগ</a>
<hr>
<a href="#"> হিসাববিজ্ঞান বিভাগ</a>
<hr>
<a href="#"> ব্যবস্থাপনা বিভাগ</a>
<hr>
     		 </div>
  	 </div>
  		 <div class="partOne"><br>
	<div class="dateTime" id="date" align="left"></div>
		<div class="mujib" align="right">
	<img src="site/a.png"/>
			</div>
			<!--
		<div class="headLine">
		<table>
	<tr>
	<td class="headSpan">
	<span>Headline</span>
	</td>
<td class="headMar"> <marquee>WorldHello WorldWorldHello WorldWorldHello WorldWorldHello WorldWorldHello World </marquee>
</td>
</tr>
		</table>
			</div>
			
			
			
			-->
			<br>
<img name="slide" class="slider" width="100%" height="200"><br><br>
				</div>
			<br>
	<div class="profInfo">
	<div style="font-size: 20px; font-weight: bold;margin-left: 20px;">
		অধ্যক্ষ,<br>
		সরকারি ইস্পাহানী কলেজ
		
	</div>
	
<br>
		<div class="prof" align="center">
		
	<img src="site/m2.jpg"/>
		
		</div>
		<div class="namePlate">
		<p style="font-size: 18px"><b>প্রফেসর রওশান আরা বেগম</b></p>
	
		</div>
	</div>
   
<div class="about" style="overflow-wrap: break-word;font-size:20px;">
<div class="headAbout">
About our collage
</div><br>
রাজধানী ঢাকার উপকণ্ঠে বুড়িগঙ্গা-ধলেশ্বরী নদী পরিবেষ্টিত মনোরম প্রাকৃতিক সৌন্দর্যে আচ্ছাদিত ঢাকা-বান্দুরা/নবাবগঞ্জ সড়কের পার্শ্বে বাংলার ঐতিহ্যবাহী তাঁত শিল্প সমৃদ্ধ এলাকা রামেরকান্দায় (রোহিতপুর) অবস্থিত অত্র জনপদের একমাত্র স্নাতক (সম্মান) ও স্নাতকোত্তর শ্রেণির পাঠদানকারী উচ্চ শিক্ষার সর্ববৃহৎ প্রতিষ্ঠান সরকারি ইস্পাহানী কলেজ। ছাত্র-ছাত্রীদের সুন্দর জীবনের প্রত্যাশায় ও সুদৃঢ় ভীত রচনায় এবং শিক্ষা, শৃঙ্খলা ও প্রগতিকে সামনে রেখে এলাকার স্বনামধন্য ব্যক্তিত্ব ও বিশিষ্ট শিক্ষানুরাগী জনাব মো: ফজলুল করিম (জন্ম- ১৯২৬, মৃত্যু ১০ জানুয়ারি, ১৯৯৮) এর উদ্যোগে ১৯৭০ সালে স্থাপিত হয় সরকারি ইস্পাহানী কলেজ। প্রতিষ্ঠালগ্নে আরও কতিপয় স্বনামধন্য বিদ্যোৎসাহী ব্যক্তিবর্গ বিশেষত ভাষাসৈনিক ও শিল্পী জনাব ইমদাদ হোসেন কলেজ প্রতিষ্ঠায় বিশেষ অবদান রাখেন। কলেজটি মহান মুক্তিযুদ্ধের সময় জাতির সূর্য সন্তানদের সান্ধ্যকালীন প্রশিক্ষণ ক্যাম্প বলে খ্যাত হয়েছে। এছাড়াও প্রগতিশীল চিন্তা, চেতনা ও মুক্তবুদ্ধি চর্চার কেন্দ্র হিসেবে সর্বাধিক পরিচিতি লাভ করেছে।
<br><br>
ইতোমধ্যে উচ্চ মাধ্যমিক, স্নাতক (পাস), স্নাতক (সম্মান), ও স্নাতকোত্তর প্রথম পর্ব এবং শেষ পর্বের কোর্সে বাংলাদেশের বিভিন্ন অঞ্চলের প্রায় ৩,৫০০ এর অধিক শিক্ষার্থী নিজেদের মেধা, যোগ্যতা ও স্বীয় লক্ষ্যকে বাস্তবায়নের জন্য এগিয়ে যাচ্ছে। শিক্ষা ও জ্ঞান বিস্তারের মহতী আদর্শে উদ্বুদ্ধ হয়ে নিয়োগকৃত প্রায় অর্ধশতাধিক শিক্ষকমণ্ডলী বিভিন্ন বিষয়ে ও ৪ টি বিভাগে নিয়মিত পাঠদান ও পরীক্ষা গ্রহণের মাধ্যমে শিক্ষার্থীদের সৃজনশীল প্রতিভাকে উদ্ভাসিত ও বিকশিত করার দৃঢ় অঙ্গীকারে নিবিড় পরিচর্যা করছে। ফলশ্রুতিতে ১৯৯৭ সালে সমগ্র বাংলাদেশে বি.এসসি (পাস) কোর্সে জাতীয় বিশ্ববিদ্যালয়ে প্রথম স্থানসহ অনেক শিক্ষার্থী মেধা তালিকায় স্থান পেয়েছে। এছাড়া ২০১৬ সালে উপজেলার শ্রেষ্ঠ প্রতিষ্ঠানের মর্যাদায় ভূষিত হয়। তারই ধারাবাহিকতায় অদ্যাবধি সকল কোর্সে বোর্ড ও বিশ্ববিদ্যালয়ের চূড়ান্ত পরীক্ষাসমূহে এ কলেজের শিক্ষার গুণগতমান এবং পাশের হার অত্যন্ত সন্তোষজনক।
<br><br>
এ কলেজে রাজনৈতিক সম্প্রীতি ও সৌহার্দ্যপূর্ণ অবস্থা সর্বদা বিরাজমান থাকে। শিক্ষা মানুষের মেধা মননের বিকাশ ঘটায়, জীবন যুদ্ধে জয়ী হওয়ার প্রেরণা যোগায়। সে আশায় উদ্দীপ্ত হয়ে, জাতির ভবিষ্যতকে সামনে রেখে, অতীত ঐতিহ্যের পথ অনুসরণ করে, সকলের জন্য শিক্ষা বিস্তারে এ প্রতিষ্ঠান অনন্য অবদান রাখছে। উল্লেখ্য যে, বর্তমানে কলেজটি জাতির জনকের সুযোগ্য কন্যা মাননীয় প্রধানমন্ত্রী জননেত্রী শেখ হাসিনার ঐকান্তিক প্রচেষ্টায় সরকারি হয়। সরকারিকরণের আনুষঙ্গিক প্রক্রিয়া সুসম্পন্ন হলে সকল শিক্ষার্থী ও শিক্ষকবৃন্দ এবং অত্র জনপদের জনগণ অচিরেই সুফল পাবে। 
</div> 
<br>
<div class="footer">
<div class="boxF">

<footer class="footer-section">
        <div class="container">
            <div class="footer-cta pt-5 pb-5">
                <div class="row">
                    <div class="col-xl-4 col-md-4 mb-30">
                        <div class="single-cta">
                           <span class="material-icons">place</span>
                            <div class="cta-text">
                                <h4>Find us</h4>
                                <span>Ramerkanda, Keraniganj, Dhaka 1310</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-4 mb-30">
                        <div class="single-cta">
                            <span class="material-icons">call</span>
                            <div class="cta-text">
                                <h4>Call us</h4>
                                <span>9876543210 0</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-4 mb-30">
                        <div class="single-cta">
                           <span class="material-icons">alternate_email</span>
                            <div class="cta-text">
                                <h4>Mail us</h4>
                                <span>ispahanicollage@gmail.com</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-content pt-5 pb-5">
                <div class="row">
                    <div class="col-xl-4 col-lg-4 mb-50">
                        <div class="footer-widget">
                            <div class="footer-logo">
                                <a href="index.html"><img src="site/logo.png" class="img-fluid" alt="logo"></a>
                            </div>
                            <div class="footer-text">
                                <p> <p>Copyright &copy; 2018, All Right Reserved Govt. Ispahani Collage.</p>
                            </div>
                            <div class="footer-social-icon">
                              
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 mb-30">
                        <div class="footer-widget">
                            <div class="footer-widget-heading">
                                <h3>Useful Links</h3>
                            </div>
                            <ul>
                                <li><a href="#">Home</a></li>
                                <li><a href="#">about</a></li>
                                <li><a href="#">services</a></li>
                                <li><a href="#">portfolio</a></li>
                                <li><a href="#">Contact</a></li>
                                <li><a href="#">About us</a></li>
                                <li><a href="#">Our Services</a></li>
                                <li><a href="#">Expert Team</a></li>
                                <li><a href="#">Contact us</a></li>
                                <li><a href="#">Latest News</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 mb-50">
                        <div class="footer-widget">
                            <div class="footer-widget-heading">
                                <h3>Subscribe</h3>
                            </div>
                            <div class="footer-text mb-25">
                                <p>Don’t miss to subscribe to our new feeds, kindly fill the form below.</p>
                            </div>
                            <div class="subscribe-form">
                                <form action="#">
                                    <input type="text" placeholder="Email Address">
                                    <button><span class="material-icons">send</span></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright-area">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6 col-lg-6 text-center text-lg-left">
                        
                           
                    </div>
                    <div class="col-xl-6 col-lg-6 d-none d-lg-block text-right">
                        <div class="footer-menu">
                            <ul>
                                <li><a href="#">Home</a></li>
                                <li><a href="#">Terms</a></li>
                                <li><a href="#">Privacy</a></li>
                                <li><a href="#">Policy</a></li>
                                <li><a href="#">Contact</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    
</div>
</div>
</div>
<div class="navBar" align="center">
<table>
<tr>
<td>
<img class="pinHome" src="pinch/home.png"/>
</td>
<td><a href="notice/"><img class="pinNotice" src="pinch/notice.png"/></a>
</td><td>
<img src="pinch/logo.png"/>
</td>
<td>
<img class="pinInfo" src="pinch/info.png"/>
</td>
<td>

<a href="profile/"><img class="pinUser" src="pinch/user.png"/></a>

</td>
</tr>
<tr>
<td class="tableHome" style="">
Home <b> • </b>
</td>
<td>
Notice
</td>
<td>
&nbsp;
</td>
<td>
Info
</td>
<td>
Profile
</td>
</tr>
</table>
</div>
</body>
<script>

var i = 0; 
	var images = [];
	var time = 2500;

	
	images[0] = 'image1.jpg';
	images[1] = 'image2.jpg';
	images[2] = 'image3.jpg';
	images[3] = 'image4.jpg';

	
	function changeImg(){
		document.slide.src = images[i];

		if(i < images.length - 1){
			i++;
		} else {
			i = 0;
		}

		setTimeout("changeImg()", time);
	}

	window.onload = changeImg;

</script>
</html>