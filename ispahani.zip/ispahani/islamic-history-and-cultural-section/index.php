<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
     <link href="site/l.png" rel="icon">
  <link href="site/l.png" rel="apple-touch-icon">
  <link href = 'https://fonts.googleapis.com/icon?family=Material+Icons' rel = 'stylesheet'>
 <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.css" rel="stylesheet">
<meta name="author" content="Govt Ispahani Collage">
<meta charset="UTF-8">
  <meta name="description" content="Welcome to the Govt Ispahani Collage Website. Stay connected with us for getting notices and more information.">
  <meta name="keywords" content="Collage, Govt Collage, Ispahani Collage, Govt Ispahani Collage">
	<meta name="viewport" content="width=device-width, initial-scale=1 user-scalable=no">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>ইসলাম ইতিহাস ও সংস্কৃতি বিভাগ</title>
    <style>
    .header{
width:100%;
height:60px;
background: #E0115F;
overflow: hidden;
  padding-top: 10px;
  position: fixed;
  top:0;
  
}
#spanLeft{
font-size: 50px;
color: whitesmoke;
float:left;
padding-right:50px;

}
.headerText{
float:left;
color: whitesmoke;
font-family:'en';
font-size: 22px;
}

    
    </style>
  </head>
  <body>
  <div class="header">

<span class="headerText"><a href="../index.php"><span class="material-icons" id="spanLeft">chevron_left</span></a></span>
</div>
<br><br><br><br>
    <h1><b>ইসলাম ইতিহাস ও সংস্কৃতি বিভাগ :</b></h1>
<br>
<p>
শিক্ষার সর্ববৃহৎ প্রতিষ্ঠান সরকারি ইস্পাহানী কলেজ। ছাত্র-ছাত্রীদের সুন্দর জীবনের প্রত্যাশায় ও সুদৃঢ় ভীত রচনায় এবং শিক্ষা, শৃঙ্খলা ও প্রগতিকে সামনে রেখে এলাকার স্বনামধন্য ব্যক্তিত্ব ও বিশিষ্ট শিক্ষানুরাগ জনাব মাে: ফজলুল করিম (জন্ম- ১৯২৬, মৃত্যু ১০ জানুয়ারি, ১৯৯৮) এর উদ্যোগে ১৯৭০ সালে স্থাপি হয় সরকারি ইস্পাহানী কলেজ। প্রতিষ্ঠালগ্নে আরও কতিপয় স্বনামধন্য বিদ্যোৎসাহী ব্যক্তিবর্গ বিশেষ ভাষাসৈনিক ও শিল্পী জনাব ইমদাদ হােসেন কলেজ প্রতিষ্ঠায় বিশেষ অবদান রাখেন। কলেজটি মহান মুক্তিযুদ্ধের সময় জাতির সূর্য সন্তানদের সান্ধ্যকালীন প্রশিক্ষণ ক্যাম্প বলে খ্যাত হয়েছে। এছাড়াও প্রগতিশীল চিন্তা, চেতনা ও মুক্তবুদ্ধি চর্চার কেন্দ্র হিসেবে সর্বাধিক পরিচিতি লাভ করেছে।
ইতােমধ্যে উচ্চ মাধ্যমিক, স্নাতক (পাস), স্নাতক (সম্মান), ও স্নাতকোত্তর প্রথম পর্ব এবং শেষ পর্বের কোর্সে বাংলাদেশের বিভিন্ন অঞ্চলের প্রায় ৩,৫০০ এর অধিক শিক্ষার্থী নিজেদের মেধা, যােগ্যতা ও স্বীয় লক্ষ্যকে বাস্তবায়নের জন্য এগিয়ে যাচ্ছে। শিক্ষা ও জ্ঞান বিস্তারের মহতী আদর্শে উদ্বুদ্ধ হয়ে নিয়ােগকৃত প্রায় অর্ধশতাধিক শিক্ষকমণ্ডলী বিভিন্ন বিষয়ে ও ৪ টি বিভাগে নিয়মিত পাঠদান ও পরীক্ষা গ্রহণের মাধ্যমে শিক্ষার্থীদের সৃজনশীল প্রতিভাকে উদ্ভাসিত ও বিকশিত করার দৃঢ় অঙ্গীকারে নিবিড় পরিচর্যা করছে। ফলশ্রুতিতে ১৯৯৭ সালে সমগ্র বাংলাদেশে বি.এসসি (পাস) কোর্সে জাতীয় বিশ্ববিদ্যালয়ে প্রথম স্থানসহ অনেক শিক্ষার্থী মেধা তালিকায় স্থান পেয়েছে। এছাড়া ২০১৬ সালে উপজেলার শ্রেষ্ঠ প্রতিষ্ঠানের মর্যাদায় ভূষিত হয়। তারই ধারাবাহিকতায় অদ্যাবধি সকল কোর্সে বাের্ড ও বিশ্ববিদ্যালয়ের চূড়ান্ত পরীক্ষাসমূহে এ কলেজের শিক্ষার গুণগতমান এবং পাশের হার অত্যন্ত সন্তোষজনক।
এ কলেজে রাজনৈতিক সম্প্রীতি ও সৌহার্দ্যপূর্ণ অবস্থা সর্বদা বিরাজমান থাকে। শিক্ষা মানুষের মেধা মননের বিকাশ ঘটায়, জীবন যুদ্ধে জয়ী হওয়ার প্রেরণা যােগায়। সে আশায় উদ্দীপ্ত হয়ে, জাতির ভবিষ্যতকে সামনে রেখে, অতীত ঐতিহ্যের পথ অনুসরণ করে, সকলের জন্য শিক্ষা বিস্তারে এ প্রতিষ্ঠান অনন্য অবদান রাখছে। উল্লেখ্য যে, বর্তমানে কলেজটি জাতির জনকের সুযােগ্য কন্যা মাননীয় প্রধানমন্ত্রী জননেত্রী শেখ হাসিনার ঐকান্তিক প্রচেষ্টায় সরকারি হয়। সরকারিকরণের আনুষঙ্গিক প্রক্রিয়া সুসম্পন্ন হলে সকল শিক্ষার্থী ও শিক্ষকবৃন্দ এবং অত্র জনপদের জনগণ অচিরেই সুফল পাবে।
বিভাগ পরিচিতি
ইসলামের ইতিহাস ও সংস্কৃতি বিভাগ কলেজটিতে ইসলামের ইতিহাস ও সংস্কৃতি বিভাগ প্রথম অনার্স কোর্স চালু করে ২০১২ সালে। পরবর্তীতে উক্ত বিভাগে ২০১৫ সালে মাস্টার্স প্রিলিমিনারি এবং ২০১৮ সালে মাস্টার্স শেষ বর্ষ চালু করা হয়। বিভাগটিতে দক্ষ ও মেধাবী শিক্ষকমণ্ডলী শিক্ষা বিস্তারে নিষ্ঠার সাথে পাঠদান করে যাচ্ছে। বিভাগের ভর্তি কার্যক্রম, শিক্ষাকার্যক্রম এবং ফলাফল প্রণয়ন সবই জাতীয় বিশ্ববিদ্যালয়ের অধীনে পরিচালিত হয়। এই বিভাগের সকল ডিগ্রী জাতীয় বিশ্ববিদ্যালয় হতে প্রদান করা হয়। উচ্চ মাধ্যমিক পর্যায়ে কারও উক্ত বিষয় থাকলে কোর্স সম্পন্ন করতে সহজ হয়।

</p>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
  </body>
</html>