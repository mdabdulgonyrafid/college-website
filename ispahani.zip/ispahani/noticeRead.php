<?php
include('php/con.php');
$getId=mysqli_real_escape_string($db,$_GET['id']);
?>
<html>
<head>
<title>Govt. Ispahani Collage</title>

<script src='https://code.jquery.com/jquery-2.1.3.min.js'></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

 <link href="../site/l.png" rel="icon">
  <link href="../site/l.png" rel="apple-touch-icon">
  <link href = 'https://fonts.googleapis.com/icon?family=Material+Icons' rel = 'stylesheet'>
  
<script src='https://code.jquery.com/jquery-2.1.3.min.js'></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
 <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.css" rel="stylesheet">
<meta name="author" content="Govt Ispahani Collage">
<meta charset="UTF-8">
  <meta name="description" content="Welcome to the Govt Ispahani Collage Website. Stay connected with us for getting notices and more information.">
  <meta name="keywords" content="Collage, Govt Collage, Ispahani Collage, Govt Ispahani Collage">
	<meta name="viewport" content="width=device-width, initial-scale=1 user-scalable=no">
<style>
@font-face{
font-family:'en';
src: url('../fonts/english.ttf');
}
body,*{
margin:0;
padding:0;
}
.header{
width:100%;
height:60px;
background: #E0115F;
overflow: hidden;
  padding-top: 10px;
  position: fixed;
  top:0;
  
}
#spanLeft{
font-size: 50px;
color: whitesmoke;
float:left;
padding-right:50px;

}
.headerText{
float:left;
color: whitesmoke;
font-family:'en';
font-size: 22px;
}

.noticeReact{
float: left;
}
.react{
width: 150px;
//border: 1px solid black;
float: left;
border-radius: 100px;
background: rgba(211,211,211,.6);
padding: 10px;
margin-left:5px;
margin-right: 20px;
}

/* -----------------------------------------
  =Default css to make the demo more pretty
-------------------------------------------- */


.load-wrapp {
  position: fixed;
  top:0;
  bottom:0;
  left:0;
  right:0;
  width: 100%;
  height: 100%;
  padding: 200px 100px 100px 100px;
  border-radius: 5px;
  text-align: center;
  background-color: #fff;
}

.load-wrapp p {
  padding: 0 0 20px;
}
.load-wrapp:last-child {
  margin-right: 0;
}

.line {
  display: inline-block;
  width: 15px;
  height: 15px;
  border-radius: 15px;
  background-color: #4b9cdb;
}

.ring-1 {
  width: 10px;
  height: 10px;
  margin: 0 auto;
  padding: 10px;
  border: 7px dashed #4b9cdb;
  border-radius: 100%;
}

.ring-2 {
  position: relative;
  width: 45px;
  height: 45px;
  margin: 0 auto;
  border: 4px solid #4b9cdb;
  border-radius: 100%;
}

.ball-holder {
  position: absolute;
  width: 12px;
  height: 45px;
  left: 17px;
  top: 0px;
}

.ball {
  position: absolute;
  top: -11px;
  left: 0;
  width: 16px;
  height: 16px;
  border-radius: 100%;
  background: #4282b3;
}

.letter-holder {
  padding: 16px;
}

.letter {
  float: left;
  font-size: 14px;
  color: #777;
}

.square {
  width: 12px;
  height: 12px;
  border-radius: 4px;
  background-color: #4b9cdb;
}

.spinner {
  position: relative;
  width: 45px;
  height: 45px;
  margin: 0 auto;
}

.bubble-1,
.bubble-2 {
  position: absolute;
  top: 0;
  width: 25px;
  height: 25px;
  border-radius: 100%;
  background-color: #4b9cdb;
}

.bubble-2 {
  top: auto;
  bottom: 0;
}

.bar {
  float: left;
  width: 15px;
  height: 6px;
  border-radius: 2px;
  background-color: #4b9cdb;
}

/* =Animate the stuff
------------------------ */
.load-5 .ball-holder {
  animation: loadingE 1.3s linear infinite;
}

.l-5 {
  animation-delay: 0.96s;
}

@keyframes loadingE {
  0 {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

</style>
</head>
<body onload="setInterval(function(){document.querySelector('#loadA').setAttribute('style','display:none;');},2500);">


<div class="load-wrapp" align="center" style="" id="loadA">
      <div class="load-5">
        <div class="ring-2">
          <div class="ball-holder">
            <div class="ball"></div>
          </div>
        </div>
      </div>
    </div>

<div class="header">

<span class="headerText"><a href="../index.php"><span class="material-icons" id="spanLeft">chevron_left</span></a>Notice Board</span>
</div>
<br><br><br>
	
	
	
	
<?php
$fet=mysqli_query($db,"SELECT * FROM notice WHERE nid='$getId'");
while($fetchA=mysqli_fetch_array($fet)){
$n=mysqli_fetch_array(mysqli_query($db,"SELECT * FROM users WHERE uid='{$fetchA['poster_id']}'"));


?>






	<div class="main">
	

		<div class="nameBar">
	<table>
 <tr>
  <td>
  <img style="height:50px;width:50px;border-radius:50%;border:2px solid #fff;outline:2px solid #E0115F;" src="teachers_profile/<?php echo $n['profile'];?>"/>
  </td>
  <td>
 &nbsp; <span style="font-family:arial;font-weight: bold;"><?php echo $n['name'];?></span>
 <?php
 if($n['blue']=='0'){}else{
?>
 <span class="material-icons" style="font-size: 16px;color:rgba(0,0,255,.5);margin-left:3px;">verified</span>
 <?php }?>
 &nbsp;<span style="font-family: arial;">posted a notice.</span></span><br>
&nbsp;  

<span style="font-family: arial;color:rgba(0,0,0,.7);font-size:14px;">
<?php
$timestamp= $fetchA['date'];
 date_default_timezone_set('Asia/Dhaka');  
// echo facebook_time_ago();  
      $time_ago = strtotime($timestamp);  
      $current_time = time();  
      $time_difference = $current_time - $time_ago;  
      $seconds = $time_difference;  
      $minutes      = round($seconds / 60 );   
      $hours           = round($seconds / 3600); 
      $days          = round($seconds / 86400); 
      $weeks          = round($seconds / 604800);
      $months          = round($seconds / 2629440);    
   
      $years          = round($seconds / 31553280);   
      if($seconds <= 60)  
      {  
     echo "$seconds second ago";  
   }  
      else if($minutes <=60)  
      {  
     if($minutes==1)  
           {  
       echo "1 minute ago";  
     }  
     else  
           {  
       echo "$minutes minutes ago";  
     }  
   }  
      else if($hours <=24)  
      {  
     if($hours==1)  
           {  
       echo "An hour ago";  
     }  
           else  
           {  
       echo "$hours hrs ago";  
     }  
   }  
      else if($days <= 7)  
      {  
     if($days==1)  
           {  
       echo "Yesterday";  
     }  
           else  
           {  
       echo "$days days ago";  
     }  
   }  
      else if($weeks <= 4.3) //4.3 == 52/12  
      {  
     if($weeks==1)  
           {  
       echo "A week ago";  
     }  
           else  
           {  
       echo "$weeks weeks ago";  
     }  
   }  
       else if($months <=12)  
      {  
     if($months==1)  
           {  
       echo "A month ago";  
     }  
           else  
           {  
       echo "$months months ago";  
     }  
   }  
      else  
      {  
     if($years==1)  
           {  
       echo "1 year ago";  
     }  
           else  
           {  
       echo "$years years ago";  
     }  
   }  
?> • <span style="color:rgba(0,0,0,.7);font-size: 14px;" class="material-icons">public</span></span>


  
  </td>
 </tr>
	</table>
		</div>
	<div class="capBar" style="font-family: arial;margin-left: 10px;">
<?php echo $fetchA['caption'];?>
		</div>
	
	<?php
	if($fetchA['photo_link']=='0'){}else{
	?>
	<img style="width:100%;height: auto" src="photo_of_notice/
<?php echo $fetchA['photo_link'];?>"/>
	
	<?php
	}
	
	?>
<span style="margin-left:10px;font-family:arial;font-weight:300;" id="lc<?php echo $fetchA['nid'];?>">
<?php echo $fetchA['total_likes'];?></span><span style="font-family:arial;font-weight:300;">&nbsp;likes</span><span style="float: right;margin-right:10px;font-family: arial;font-weight:300;">
<?php echo $fetchA['total_shear'];?> shares</span>
		
		
		
		
		<div class="noticeReact">
	<div class="react" onclick="like('<?php echo $fetchA['nid'];?>')">
<table>
<tr>
<td>
<span class="material-icons" style="font-size: 30px;float: left;margin-left:25px;">favorite_border</span>
</td>
<td>
<span class="reactText">&nbsp;Love</span>
</td>
</tr>
</table>
</div>

<div class="react" onclick="ap('<?php echo $fetchA['nid'];?>');">
<table>
<tr>
<td>
<span class="material-icons" style="font-size: 30px;float: left;margin-left:25px;">share</span>
</td>
<td>
<span class="reactText" >&nbsp;Share</span>
</td>
</tr>
</table>
	</div>
			</div>
	
	
	
	
	

<div class="shear" id="jsPop<?php echo $fetchA['nid'];?>" style="position: fixed;width: 100%;height: 140px;background: #fff;bottom:0;display:none;" >

<span style="font-family: arial;margin-top:10px;margin-left:5px;font-size:20px;font-weight: bold;float:left;">Share to</span><span style="font-size: 30px;float: right;margin-right:10px;" onclick="asp('<?php echo $fetchA['nid'];?>');">&times;</span>

		<div class="icons">
			<table style="font-family: arial;">
			 <tr>
			  <td>
			
<span class="material-icons" style="background: rgba(211,211,211,.6);font-size: 40px;padding:7px;border-radius: 50%;color: rgba(0,0,0,.8);float:left;margin-left:10px;margin-top:10px;" onclick='navigator.clipboard.writeText("http://localhost:8080/ispahani/noticeRead.php?id=<?php echo $fetchA['nid'];?>");alert("Link Copied");'>content_copy</span>
	</td>
	 <td>
<a href="https://www.facebook.com/sharer.php?u=https://localhost:8080/ispahani/noticeRead.php?id=<?php echo $fetchA['nid'];?>"><span style="background: ;font-size: 40px;padding:7px;border-radius: 50%;color: rgba(0,0,0,.8);float:left;margin-left:10px;margin-top:0px;"><img src="site/f.png" style="height:55px;width:55px;"></span></a>
 </td>
  <td>
<span style="background: ;font-size: 40px;padding:7px;border-radius: 50%;color: rgba(0,0,0,.8);float:left;margin-left:10px;margin-top:0px;"><img src="site/w.jpeg" style="height:55px;width:100px;"></span>
</td>
 <td>
 <?php
 if($fetchA['photo_link']=='0'){?>
 
 
<span style="background: rgba(211,211,211,.6);font-size: 40px;padding:7px;border-radius: 50%;color: rgba(0,0,0,.8);float:left;margin-left:10px;margin-top:10px;" class="material-icons">file_download_off</span>

 
<?php }else{
?>
<a href="../photo_of_notice/<?php echo $fetchA['photo_link'];?>" download="<?php echo $fetchA['photo_link'];?>"/><span style="background: rgba(211,211,211,.6);font-size: 40px;padding:7px;border-radius: 50%;color: rgba(0,0,0,.8);float:left;margin-left:10px;margin-top:10px;" class="material-icons">file_download</span></a>
<?php }?>
</td>
</tr>
<tr>
<td>
&nbsp;Copy link
</td>
<td>
</td>
<td>
</td>
<td>
 <?php
 if($fetchA['photo_link']=='0'){echo 'Unable ';
}else{

echo 'Save Image';

}?>
</td>
</table>
			</div>
	
	
	
	
	
	
	</div>

	<?php
	}
	?>

</body>
<script>


function like(id){
var cur_count=jQuery('#lc'+id).html();
cur_count++;
jQuery('#lc'+id).html(cur_count);
jQuery.ajax({
url:'profile/like.php',
type:'get',
data:'p='+id,
success:function(result){


}

});

}



 


 function ap(a){
var b=document.querySelector('#jsPop'+a);
var c=b.getAttribute('style');
if(c=="position: fixed;width: 100%;height: 140px;background: #fff;bottom:0;display:none;"){
b.setAttribute('style','position: fixed;width: 100%;height: 140px;background: #fff;bottom:0;display:;');
}else{
b.setAttribute('style','position: fixed;width: 100%;height: 140px;background: #fff;bottom:0;display:none;');
}
}

function asp(a){
var b=document.querySelector('#jsPop'+a);
var c=b.getAttribute('style');
if(c=="position: fixed;width: 100%;height: 140px;background: #fff;bottom:0;display:;"){
b.setAttribute('style','position: fixed;width: 100%;height: 140px;background: #fff;bottom:0;display:none;');
}
}



</script>
</html>