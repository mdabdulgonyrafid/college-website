<?php
date_default_timezone_set('Asia/Dhaka');  
echo date("h:i:s A • d-M-Y") ;
?>