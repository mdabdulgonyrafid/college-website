<?php
include('../php/con.php');
session_start();
$sessUser="";
if(isset($_SESSION['username'])){
$sessUser= htmlspecialchars($_SESSION['username']);
}
if($sessUser){ }else{
header('location:../admin/');
}
$uName="";
$uPass="";
$uEmail="";
$uNumber="";
if(isset($_POST['userName'])){
$uName=htmlspecialchars($_POST['userName']);
$uPass=htmlspecialchars($_POST['userPass']);
$uEmail=htmlspecialchars($_POST['userEmail']);
$uNumber=htmlspecialchars($_POST['userNumber']);
}
$verify_code=rand(314342,999999);
$uId=rand(251322532,99999999);
$info="";
$ms=mysqli_query($db,"SELECT * FROM users WHERE email='$uEmail'");
if(mysqli_num_rows($ms)==1){
$info="Email is already in use";
}else{

if(isset($_POST['sub'])){
mysqli_query($db,"INSERT INTO users(id,name,email,pass,phone,uid,verify_code,verify_status,blue,profile) VALUES(null,'$uName','$uEmail','$uPass','$uNumber','$uId','$verify_code','0','0','man.jpg')");
header('location:middle.php?a='.$uEmail.'&b=Govt Ispahani Collage verification code&c=Hi,'.$uName.'<br>Here is your verification code : '.$verify_code.'<br>Thanks for requesting a verification code');
}

}
$fsql=mysqli_query($db,"SELECT * FROM users");
if(isset($_POST['suu'])){
mysqli_query($db,"DELETE FROM users WHERE uid='{$_POST['dUid']}'");
header('location: addTeacher.php');
}

if(isset($_POST['dsub'])){
mysqli_query($db,"UPDATE users SET blue='{$_POST['dB']}' WHERE uid='{$_POST['xUid']}'");
header('location: addTeacher.php');
}
?>
<html>
<head>
<title>BackDoor</title>
 <link href="../site/l.png" rel="icon">
  <link href="../site/l.png" rel="apple-touch-icon">
  <link href = 'https://fonts.googleapis.com/icon?family=Material+Icons' rel = 'stylesheet'>
  
<script src='https://code.jquery.com/jquery-2.1.3.min.js'></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
 <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.css" rel="stylesheet">
<meta name="author" content="Govt Ispahani Collage">
<meta charset="UTF-8">
  <meta name="description" content="Welcome to the Govt Ispahani Collage Website. Stay connected with us for getting notices and more information.">
  <meta name="keywords" content="Collage, Govt Collage, Ispahani Collage, Govt Ispahani Collage">
	<meta name="viewport" content="width=device-width, initial-scale=1 user-scalable=no">
	<style>
	
@font-face{
font-family:'en';
src: url('../fonts/english.ttf');
}
	body{
	margin:0;
	padding:0;
	font-family: sanserif;
	}
	.header{
	position: fixed;
	width:100%;
	top:0;
	height: 60px;
	background: #E0115F;
	font-family: sanserif;
	color: white;
	font-size: ;
	
	}
	.nav{

	}
	.totalTeacher{
	float: left;
	background: rgba(255,3,176);
	
	height:80px;
	width:130px;
	font-size: 17px;
	margin-left:3px;
	color: #fff;
	font-weight: Bold;
	}
	.totalNotice{
	float: left;
	background: rgba(255,3,73);
	height:80px;
	width:130px;
	font-size: 20px;
	font-size: 17px;
	margin-left:3px;
	color: #fff;
	font-weight: Bold;
	}
	.totalLikes{
	float: left;
	background: rgba(106,32,6);
	height:80px;
	width:130px;
	font-size: 20px;
	font-size: 17px;
	margin-left:3px;
	color: #fff;
	font-weight: Bold;
	
	}
	.totalTeacher span,.totalNotice span,.totalLikes span{
	font-size: 30px;
	
	}
	.totalTeacher,.totalNotice,.totalLikes{
	border-radius: 5px;
	padding-top:10px;
	margin-bottom: 10px;
	
	}
	a{
	text-decoration: none;
	color: #fff;
	}
	.userName{
	border:1px solid rgba(0,0,0,.4);
	}
	input[type=submit]{
	border:none;
	font-size: 18px;
	background:#3b5998;
	color: #fff;
	margin-left: 10px;
	border-radius: 5px;
	padding:2px;
	}
	</style>
<body >
	<div class="header" align="center">
	<span class="material-icons" style="float: left;font-size: 38px;margin-top:10px;margin-left: 5px;border: 1px solid rgba(255,255,255,.4);" onclick="strt()">
menu
</span>
	<br>
	<table style="color: white;">
	 <tr>
	  <td>
<p>Dashboard</p>
  </td>
   <td><span class="material-icons">
dashboard
</span>
 </td>
  </tr>
   </table>
	</div>
	<br>
	<br><br>
<div class="nav" style="position: fixed;width:220px;background: #E0115F;left:0;height:100%;color: #fff;display:none;" id="navBar">
<h3 style="font-family:;">Customize</h3>
<a href="../admin/">&nbsp;•&nbsp;<b>Dashboard</b></a>
		<table style="color: #fff;font-family: 'en';">
				<tr>
				 <td>
<span>&nbsp•&nbsp;Update Headline</span>

</td>
<td>
<span class="material-icons">update</span>
</td>
</tr>

			<tr>
				 <td>
<span>&nbsp•&nbsp;Update Professor Photo</span>

</td>
<td>
<span class="material-icons">update</span>
</td>
			</tr>
			
				<tr>
				 <td>
<span>&nbsp•&nbsp;Update Footer Info</span>

</td>
<td>
<span class="material-icons">update</span>
</td>
</tr>
			<tr>
				 <td>
<span>&nbsp•&nbsp;<a href="addTeacher.php">Add / Delete Teachers</a></span>

</td>
<td>
<span class="material-icons">add</span>
</td>
</tr>
</table>
<a href="logout.php">Logout</a>
</div><br>
	<div class="addTeacher">
	<h2>&nbsp;Add Teacher / Delete Teacher</h2>
	<div align="center">
	<?php echo $info;?>
	</div>
	 	<div class="add">
	 	<form action="" method="POST">
	 	<table >
	 	 <tr>
	 	  <td>
	 	  &nbsp;Name :
	 	  </td>
	 	  <td>
	 	  <input type="text" name="userName" class="userName"/>
	 	  </td>
	 	  </tr>
	 	 
	 	  <tr>
	 	  <td>
	 	   &nbsp;Email :
	 	  
	 	  </td>
	 	  <td>
	 	  <input type="email" name="userEmail" class="userName"/>
	 	  </td>
	 	  </tr>
	 	  <tr>
	 	  <td>
	 	  &nbsp;Phone No. :
	 	  </td>
	 	  <td>
	 	  <input type="number" name="userNumber" class="userName"/>
	 	  </td>
	 	  <tr>
	 	  <td>
	 	  &nbsp;Password :
	 	  </td>
	 	  <td>
	 	  <input type="text" name="userPass" class="userName"/>
	 	  </td>
	 	  </tr>
	 	  </table>
	 	  <br>
	 	  <input type="submit" value="Verify Email" name="sub"/>
	 	  </form>
	 	</div>
	 </div>
	 <div>
	 <p> ** Note : 0 mean FALSE & 1 mean TRUE.</p>
	 </div>
	  <div class="teacherData">
	 <table style="font-size:14px;border:1px solid black;" border="1">
	<tr>
	 <td>
	 Name
	 </td>
	 <td>
	 Email
	 </td>
	 <td>
	 Phone
	 </td>
	 <td>
	 Blue
	 </td>
	 <td>
	 Profile
	 </td>
	 <td>
	 Delection
	 </td>
	 </tr>
	 <?php
	 while($fa=mysqli_fetch_array($fsql)){
	?>
	 <tr>
	 <td>
	 <?php echo $fa['name'];?>
	 </td>
	 <td>
	 <?php echo $fa['email'];?>
	 </td>
	 <td>
	 <?php echo $fa['phone'];?>
	 </td>
	 <td>
	 <form action="" method="post">
	 <textarea rows="1" cols="2" name="dB"><?php echo $fa['blue'];?></textarea>
	 <input type="hidden" value="<?php echo $fa['uid'];?>" name="xUid"/>
	<button type="submit" name="dsub"> Save</button></form>
	 </td>
	 <td>
	 <img src="../teachers_profile/<?php echo $fa['profile'];?>" style="height:50px;width:50px;">
	 </td>
	 <td>
	 <form action="" method="POST">
	 <input type="hidden" value="<?php echo $fa['uid'];?>" name="dUid"/>
	 <button type="submit" name="suu">Delete</button>
	 </form>
	 
	 </td>
	 </tr>
	  <?php } ?>
	 </table>
	 </div>
	
</body>
<script>
function strt(){

var a=document.querySelector('#navBar');
var b=a.getAttribute('style');
if(b=="position: fixed;width:220px;background: #E0115F;left:0;height:100%;color: #fff;display:none;"){
a.setAttribute('style','position: fixed;width:220px;background: #E0115F;left:0;height:100%;color: #fff;display:;');
}else{
a.setAttribute('style','position: fixed;width:220px;background: #E0115F;left:0;height:100%;color: #fff;display:none;');
}

}
</script>
</html>