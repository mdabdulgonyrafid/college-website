<?php
include('../php/con.php');
session_start();
$sessUser="";
if(isset($_SESSION['username'])){
$sessUser= htmlspecialchars($_SESSION['username']);
}
if($sessUser){header('location: dashboard.php');}else{

}


$userLogin="";
$userPass="";
if(isset($_POST['user'])){
$userLogin=mysqli_real_escape_string($db,$_POST['user']);
$userPass=mysqli_real_escape_string($db,$_POST['pass']);
}

	
	
		
if(isset($_POST['sub'])){

$sql=mysqli_query($db,"SELECT * FROM backdoor WHERE username='$userLogin' AND password='$userPass'");
if(mysqli_num_rows($sql)==1){
$_SESSION['username'] = $userLogin;

header('location: dashboard.php');
}
}

		
?>
<html>
<head>
<title>BackDoor</title>
 <link href="../site/l.png" rel="icon">
  <link href="../site/l.png" rel="apple-touch-icon">
  <link href = 'https://fonts.googleapis.com/icon?family=Material+Icons' rel = 'stylesheet'>
  
<script src='https://code.jquery.com/jquery-2.1.3.min.js'></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
 <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.css" rel="stylesheet">
<meta name="author" content="Govt Ispahani Collage">
<meta charset="UTF-8">
  <meta name="description" content="Welcome to the Govt Ispahani Collage Website. Stay connected with us for getting notices and more information.">
  <meta name="keywords" content="Collage, Govt Collage, Ispahani Collage, Govt Ispahani Collage">
	<meta name="viewport" content="width=device-width, initial-scale=1 user-scalable=no">
	<style>
	body{
	margin:0;
	padding:0;
	font-family: sanserif;
	}
	.header{
	position: fixed;
	width:100%;
	top:0;
	height: 50px;
	background: #E0115F;
	font-family: sanserif;
	color: white;
	font-size: ;
	
	}
	.login{
	padding-top: 60px;

	}
	.loginUser{
	border: 1px solid rgba(0,0,0,.2);
	outline: none;
	font-size: 17px;
	color: rgba(0,0,0,.4);
	
	}
	.material-icons{
	font-size:;
	
	}
	</style>
	</head>
<body>
	<div class="header" align="center">
	<p> BackDoor</p>
	</div>
	 
		<div class="login" align="center">
		 <h2>BackDoor Login</h2>
		  <form action="" method="POST">
		 <table>
		  <tr>
		   <td>
	<span class="material-icons">admin_panel_settings</span>
	</td>
	 <td>
	  <input type="text" name="user" placeholder="Username" id="loginUser" class="loginUser"/>
	   </td>
	    </tr>
	     <tr>
	      <td>
	       
	<span class="material-icons">vpn_key</span> 
	 </td>
	  <td>
	   <input type="password" name="pass" placeholder="Password" id="loginPass" class="loginUser"/>
	    </td>
	     </tr>
	      </table>
	      <input type="submit" name="sub">
	       </form>
		</div>
</body>