<?php
include('../php/con.php');
session_start();
$sessUser="";
if(isset($_SESSION['username'])){
$sessUser= htmlspecialchars($_SESSION['username']);
}
if($sessUser){ }else{
header('location:../admin/');
}
$teacherCounter=mysqli_num_rows(mysqli_query($db,"SELECT * FROM users"));
$tLike=mysqli_query($db,"SELECT * FROM notice");
?>
<html>
<head>
<title>BackDoor</title>
 <link href="../site/l.png" rel="icon">
  <link href="../site/l.png" rel="apple-touch-icon">
  <link href = 'https://fonts.googleapis.com/icon?family=Material+Icons' rel = 'stylesheet'>
  
<script src='https://code.jquery.com/jquery-2.1.3.min.js'></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
 <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.css" rel="stylesheet">
<meta name="author" content="Govt Ispahani Collage">
<meta charset="UTF-8">
  <meta name="description" content="Welcome to the Govt Ispahani Collage Website. Stay connected with us for getting notices and more information.">
  <meta name="keywords" content="Collage, Govt Collage, Ispahani Collage, Govt Ispahani Collage">
	<meta name="viewport" content="width=device-width, initial-scale=1 user-scalable=no">
	<style>
	
@font-face{
font-family:'en';
src: url('../fonts/english.ttf');
}
	body{
	margin:0;
	padding:0;
	font-family: sanserif;
	}
	.header{
	position: fixed;
	width:100%;
	top:0;
	height: 60px;
	background: #E0115F;
	font-family: sanserif;
	color: white;
	font-size: ;
	
	}
	.nav{

	}
	.totalTeacher{
	float: left;
	background: rgba(255,3,176);
	
	height:80px;
	width:130px;
	font-size: 17px;
	margin-left:3px;
	color: #fff;
	font-weight: Bold;
	}
	.totalNotice{
	float: left;
	background: rgba(255,3,73);
	height:80px;
	width:130px;
	font-size: 20px;
	font-size: 17px;
	margin-left:3px;
	color: #fff;
	font-weight: Bold;
	}
	.totalLikes{
	float: left;
	background: rgba(106,32,6);
	height:80px;
	width:130px;
	font-size: 20px;
	font-size: 17px;
	margin-left:3px;
	color: #fff;
	font-weight: Bold;
	
	}
	.totalTeacher span,.totalNotice span,.totalLikes span{
	font-size: 30px;
	
	}
	.totalTeacher,.totalNotice,.totalLikes{
	border-radius: 5px;
	padding-top:10px;
	margin-bottom: 10px;
	
	}
	a{
	text-decoration: none;
	color: #fff;
	}
	</style>
<body >
	<div class="header" align="center">
	<span class="material-icons" style="float: left;font-size: 38px;margin-top:10px;margin-left: 5px;border: 1px solid rgba(255,255,255,.4);" onclick="strt()">
menu
</span>
	<br>
	<table style="color: white;">
	 <tr>
	  <td>
<p>Dashboard</p>
  </td>
   <td><span class="material-icons">
dashboard
</span>
 </td>
  </tr>
   </table>
	</div>
	<br>
	<br><br>
<div class="nav" style="position: fixed;width:220px;background: #E0115F;left:0;height:100%;color: #fff;display:none;" id="navBar">
<h3 style="font-family:;">Customize</h3>

<a href="../admin/">&nbsp;•&nbsp;<b>Dashboard</b></a>
		<table style="color: #fff;font-family: 'en';">
				<tr>
				 <td>
<span>&nbsp•&nbsp;Update Headline</span>

</td>
<td>
<span class="material-icons">update</span>
</td>
</tr>

			<tr>
				 <td>
<span>&nbsp•&nbsp;Update Professor Photo</span>

</td>
<td>
<span class="material-icons">update</span>
</td>
			</tr>
			
				<tr>
				 <td>
<span>&nbsp•&nbsp;Update Footer Info</span>

</td>
<td>
<span class="material-icons">update</span>
</td>
</tr>
			<tr>
				 <td>
<span>&nbsp•&nbsp;<a href="addTeacher.php">Add Teachers</a></span>

</td>
<td>
<span class="material-icons">add</span>
</td>
</tr>
</table>
<a href="logout.php">Logout</a>
</div><br>
	<h2>&nbsp;Statistics</h2>
	<div class="bdy">
 <div class="totalTeacher" align="center">
 Total Teachers
 <br><br>
 <span><?php echo $teacherCounter;?></span>
 </div>
    <div class="totalNotice" align="center">
    Total Notices
     <br><br>
 <span>134567</span>
     </div>
     <?php
     while($ttl=mysqli_fetch_array($tLike)){
     
     }
    ?>
       <div class="totalLikes" align="center">
       Total Likes
        <br><br>
 <span>2345677</span>
       </div>
       
	</div>
	
		<div class="bdy">
		
 <div class="totalTeacher" style="background: rgba(127,5,100);" align="center">
 Total Share
 <br><br>
 <span>48</span>
 </div>
    <div class="totalNotice"  style="background: rgba(220,100,90);" align="center">
    Total Visits
     <br><br>
 <span>134567</span>
     </div>
     
     <!-- <div class="totalLikes" align="center">
       Total Likes
        <br><br>
 <span>2345677</span>
       </div> -->
	</div>

</body>
<script>
function strt(){

var a=document.querySelector('#navBar');
var b=a.getAttribute('style');
if(b=="position: fixed;width:220px;background: #E0115F;left:0;height:100%;color: #fff;display:none;"){
a.setAttribute('style','position: fixed;width:220px;background: #E0115F;left:0;height:100%;color: #fff;display:;');
}else{
a.setAttribute('style','position: fixed;width:220px;background: #E0115F;left:0;height:100%;color: #fff;display:none;');
}

}
</script>
</html>