<?php
include('../php/con.php');
session_start();
mysqli_query($db,"UPDATE backdoor SET ip='null' WHERE username='{$_SESSION['username']}'");
unset($_SESSION['username']);
header('location:../admin/');
?>