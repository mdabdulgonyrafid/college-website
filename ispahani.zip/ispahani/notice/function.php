<?php
include('../php/con.php');
$sess=$_SESSION['uuid'];
$readParam=$_GET['param'];
$readFunction=$_GET['meth'];
if($sess){

}else{
header('location:../login/');
}

if($readFunction=="delete"){
mysqli_query($db,"DELETE FROM notice WHERE nid='$readParam'");
header('location:../profile/?back=from delete function');
}

?>