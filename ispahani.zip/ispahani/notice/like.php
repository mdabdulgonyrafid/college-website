<?php
include('../php/con.php');
$gid=$_GET['p'];


$fTl=mysqli_fetch_array(mysqli_query($db,"SELECT * FROM notice WHERE nid='$gid'"));
$tl=$fTl['total_likes'];
$tl1=$tl+1;
mysqli_query($db,"UPDATE notice SET total_likes='$tl1' WHERE nid='$gid'");





?>