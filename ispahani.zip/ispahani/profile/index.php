<?php
include('../php/con.php');
session_start();
$sess="";
if(isset($_SESSION['uuid'])){
$sess=$_SESSION['uuid'];
}else{header('location:../login/');}
$name="";
if(isset($_FILES['image']['name'])){
$name = $_FILES['image']['name'];
}
$capt="";
if(isset($_POST['cap'])){
$capt=htmlspecialchars($_POST['cap']);

}
if($name==NULL){
			if(isset($_POST['imb'])){
$postid=rand(11111111,99909999);
date_default_timezone_set('Asia/Dhaka');  
$dat=date("Y-m-d H:i:s") ;


$s=mysqli_query($db,"INSERT INTO notice(id,nid,poster_id,caption,photo_link,total_likes,total_shear,date) VALUES(null,'$postid','$sess','$capt','0','0','0','$dat')");
echo 'Error: ' . mysqli_error($db);
//header('location: profile.php');

//echo 'Error: ' . mysqli_error($db);
header('location:../profile/');

}

}else{


if($capt==""){
 $postid=rand(11111111,99909999);
date_default_timezone_set('Asia/Dhaka');  
$dat=date("Y-m-d H:i:s") ;
       // Getting file name
       $filename = $_FILES['image']['name'];
         
       // Valid extension
       $valid_ext = array('png','jpeg','jpg');

			
	   $photoExt1 = @end(explode('.', $filename)); // explode the image name to get the extension
	   $phototest1 = strtolower($photoExt1);
			
	   $new_profle_pic = uniqid("Govt_Ispahani_Collage_", true).'.'.$phototest1;
			
       // Location
       $location = "../photo_of_notice/".$new_profle_pic;

       // file extension
       $file_extension = pathinfo($location, PATHINFO_EXTENSION);
       $file_extension = strtolower($file_extension);

       // Check extension
       if(in_array($file_extension,$valid_ext)){  

            // Compress Image
            compressedImage($_FILES['image']['tmp_name'],$location,30);
            

			if(isset($_POST['imb'])){





$s=mysqli_query($db,"INSERT INTO notice(id,nid,poster_id,caption,photo_link,total_likes,total_shear,date) VALUES(null,'$postid','$sess','','$new_profle_pic','0','0','$dat')");

echo 'Error: ' . mysqli_error($db);
header('location:../profile/');



}

}

}else{

 $postid=rand(11111111,99909999);
date_default_timezone_set('Asia/Dhaka');  
$dat=date("Y-m-d H:i:s") ;
       // Getting file name
       $filename = $_FILES['image']['name'];
         
       // Valid extension
       $valid_ext = array('png','jpeg','jpg');

			
	   $photoExt1 = @end(explode('.', $filename)); // explode the image name to get the extension
	   $phototest1 = strtolower($photoExt1);
			
	   $new_profle_pic = uniqid("Govt_Ispahani_Collage", true).'.'.$phototest1;
			
       // Location
       $location = "../photo_of_notice/".$new_profle_pic;

       // file extension
       $file_extension = pathinfo($location, PATHINFO_EXTENSION);
       $file_extension = strtolower($file_extension);

       // Check extension
       if(in_array($file_extension,$valid_ext)){  

            // Compress Image
            compressedImage($_FILES['image']['tmp_name'],$location,50);
            

			if(isset($_POST['imb'])){





$s=mysqli_query($db,"INSERT INTO notice(id,nid,poster_id,caption,photo_link,total_likes,total_shear,date) VALUES(null,'$postid','$sess','$capt','$new_profle_pic','0','0','$dat')");

echo 'Error: ' . mysqli_error($db);
header('location:../profile/');



}

}

}

        
    }

    // Compress image
    function compressedImage($source, $path, $quality) {

            $info = getimagesize($source);

            if ($info['mime'] == 'image/jpeg') 
                $image = imagecreatefromjpeg($source);

            elseif ($info['mime'] == 'image/gif') 
                $image = imagecreatefromgif($source);

            elseif ($info['mime'] == 'image/png') 
                $image = imagecreatefrompng($source);

            imagejpeg($image, $path, $quality);

    
}



$upUid="";
$upNid="";
$reCap="";
if(isset($_POST['recap'])){
$reCap=$_POST['recap'];
}
if(isset($_POST['upnid'])){

$upUid=$_POST['upuid'];
$upNid=$_POST['upnid'];
}
if(isset($_POST['reup'])){

mysqli_query($db,"UPDATE notice SET caption='$reCap' WHERE nid='$upNid' AND poster_id='$upUid'");
header('location:../profile/');
}
$fPer=mysqli_fetch_array(mysqli_query($db,"SELECT * FROM users WHERE uid='$sess'"));


?>
<html>
<head>
<title>Govt. Ispahani Collage</title>
 <link href="site/l.png" rel="icon">
  <link href="site/l.png" rel="apple-touch-icon">
  <link href = 'https://fonts.googleapis.com/icon?family=Material+Icons' rel = 'stylesheet'>
 <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.css" rel="stylesheet">
<meta name="author" content="Govt Ispahani Collage">
<meta charset="UTF-8">
  <meta name="description" content="Welcome to the Govt Ispahani Collage Website. Stay connected with us for getting notices and more information.">
  <meta name="keywords" content="Collage, Govt Collage, Ispahani Collage, Govt Ispahani Collage">
	<meta name="viewport" content="width=device-width, initial-scale=1 user-scalable=no">
<script src='https://code.jquery.com/jquery-2.1.3.min.js'></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

	<script src="javascript/date.js"></script>
<script src="j.avascript/slider.js"></script>
<style>
body{
margin:0;
padding:0;
}
.nav{
position: fixed;
width:100%;
height:60px;
background: #E0115F;
color: #fff;
top:0;
}
.Pp{
width: 100px;
height: 100px;
border-radius: 50%;
border:2px solid #fff;
outline: 3px solid #E0115F;
margin-left: 20px;
margin-bottom:10px;
}
.pro{
margin-top:70px;
}
.nam{
font-size: 20px;
font-family: arial;
font-weight: bold;
margin-left: 5px;
}
.subbb{
border:none;
outline:none;
background: #3b5998;
color: #fff;
padding: 04px 0150px 04px 0150px;
margin-left: 7px;
border-radius: 6px;
font-size :20px;
}
textarea{
margin-left:10px;
border:1px solid #E0115F;
padding-left: 10px;
font-family: Arial;
}


#spanLeft{
font-size: 50px;
color: whitesmoke;
float: left;
padding-right:50px;

}
.headerText{

color: whitesmoke;
font-family:'en';
font-size: 22px;
}
.squar span img{
width:40px;
height:40px;
border-radius:50%;
border: 2px solid #fff;
outline: 3px solid #E0115F;
margin-left:5px;
float:left;
}
.spanName{
font-family:sanserif;
font-weight: bold;
float:left;
margin-left:10px;
margin-bottom: 200px;
}
.spanTime{
float: left;
font-family: sanserif;
font-size:13px;
margin-left:10px;

}
.squar{
margin-bottom:30px;

}
.noticeArea{
margin-left: 5px;
font-family: sanserif;
font-weight: 500;
word-wrap: break-word ;/*Allows unbreakable words to be broken*/
float: left;

}
.nP{
width:100%;
height:auto;
}
.noticePhoto{
margin-bottom: 10px;
}
.noticeReact{
float: left;
}
.react{
width: 150px;
//border: 1px solid black;
float: left;
border-radius: 100px;
background: rgba(211,211,211,.6);
padding: 10px;
margin-left:5px;
margin-right: 20px;
}
.reactText{
float: left;
font-family: arial;
font-size: 17px;
font-weight: 400;
}
#noticeMenu{
font-size: 25px;
margin-right: 5px;
float: right;
}
.totalReact{
font-family: arial;
font-weight: 300;
margin-left: 5px;
float: left;
}
.totalView{

font-family: arial;
font-weight: 300;
margin-left: 5px;
float: right;
margin-right: 10px;
margin-bottom: 10px;
}
.icons{
margin-top: 5px;
font-family: Arial;
}
button,a{
border: none;
background: none;
font-size: 16px;
text-decoration: none;
color: #000;
}

.filelabel .title {
  color: #0693cd;;
}
#FileInput{
    display:none;
}
</style>
</head>
<body>
<div class="nav">
<span class="material-icons" style="color:#fff;font-size:35px;float:left;margin-left:5px;margin-top:10px;">arrow_back</span><span style="color: #fff;margin-left:20px;margin-top:17px;float:left;font-family: Senserif;font-weight: 450;"><?php echo $fPer['name'];?></span>
</div>


<div class="pro">
<a href="setting.php"><span class="material-icons" style="background: rgba(211,211,211,.6);font-size: 40px;padding:7px;border-radius: 50%;color: rgba(0,0,0,.8);float:left;margin-right:20px;margin-top:10px;float: right;" >settings</span></a>
<img src="../teachers_profile/<?php echo $fPer['profile'];?>" class="Pp"/><br>
<span class="nam"><?php echo $fPer['name'];?></span>&nbsp;
<?php if($fPer['blue']=='0'){}else{?>
<span class="material-icons" style="font-size: 20px;color:rgba(0,0,255,.5);">verified</span>
<?php }?>

<br><br><a href="logout.php" style="float : right;">Logout</a>
<div style="width: 98%;height:30px;background: #E0115F;color: #fff;margin-left: 5px;margin-right:5px;border-radius:5px;" align="center">
<table style="color: #fff;font-family: arial;">
<tr>
<td>
<b>Edit Profile</b>
</td>
<td>
<span style="color:;" class="material-icons">edit</span>
</td>
</tr>
</table>
</div>
<div>
<h2 style="font-family: Arial;">Post Notice</h2>

	<div>
	 <form method="post" enctype="multipart/form-data">
	 
	<textarea rows="3" cols="35" name="cap" onkeyup="auto_grow(this)" placeholder="Write notice here...."></textarea>
	<label class="filelabel">
<span class="material-icons" style="color:#000;font-size:35px;float:;margin-left:5px;margin-top:10px;">add_photo_alternate</span>
    <input class="FileUpload1" id="FileInput" name="image" type="file" accept="image/*"/>
</label>
 <br>
  <input type="submit" class="subbb" name="imb" value="Post"/>

 	</form>
	</div>
	

<h2 style="font-family: arial;">Notice you post</h2>


<?php
$fet=mysqli_query($db,"SELECT * FROM notice WHERE poster_id='$sess' ORDER BY id DESC");
while($fetchA=mysqli_fetch_array($fet)){
$n=mysqli_fetch_array(mysqli_query($db,"SELECT * FROM users WHERE uid='{$fetchA['poster_id']}'"));


?>

	<div style="width:70%;height:200px;background:#fff;position: fixed;top:30%;bottom:0;left:50;right:0;box-shadow:1px 1px 8px 01px #000;display:none;" id="subMenu<?php echo $fetchA['nid'];?>">
	<span style="float: right;font-size:30px;margin-right:10px;" onclick="document.querySelector('#subMenu<?php echo $fetchA['nid'];?>').setAttribute('style','width:70%;height:200px;background:#fff;position: fixed;top:30%;bottom:0;left:50;right:0;box-shadow:1px 1px 8px 01px #000;display:none;');">&times;</span>
	<h2 style="margin-top:10px;margin-left: 10px;">Edit Caption</h2>
	 <form action="" method="post">
	<input type="hidden" value="<?php echo $fetchA['nid'];?>" name="upnid"/>
		<input type="hidden" value="<?php echo $fetchA['poster_id'];?>" name="upuid"/>
	<textarea rows="4" cols="auto" name="recap" placeholder="Update notice here...." style="width:90%;"><?php echo $fetchA['caption'];?></textarea>
	<br>
	
	<span style="float: left;margin-left: 20px;margin-top: 15px;background:rgba(211,211,211,.6);padding:4px;border-radius:5px;font-weight: bold;" onclick="document.querySelector('#subMenu<?php echo $fetchA['nid'];?>').setAttribute('style','width:70%;height:200px;background:#fff;position: fixed;top:30%;bottom:0;left:50;right:0;box-shadow:1px 1px 8px 01px #000;display:none;');">Cancle</span>
	
		<span style="float: right;margin-right: 20px;margin-top: 15px;background:rgba(211,211,211,.6);padding:4px;border-radius:5px;background: #3b5998;color: #fff;font-weight:bold"><input type="submit" style="border:none;background:#3b5998;color: #fff;font-weight:bold" name="reup" value="Update Edit"/></span>
	
	</form>
	</div>






	<div class="main">
	

		<div class="nameBar">
	<table>
 <tr>
  <td>
  <img style="height:50px;width:50px;border-radius:50%;border:2px solid #fff;outline:2px solid #E0115F;" src="../teachers_profile/<?php echo $n['profile'];?>"/>
  </td>
  <td>
 &nbsp; <span style="font-family:arial;font-weight: bold;"><?php echo $n['name'];?></span>
 <?php
 if($n['blue']=='0'){}else{
?>
 <span class="material-icons" style="font-size: 16px;color:rgba(0,0,255,.5);margin-left:3px;">verified</span>
 <?php }?>
 &nbsp;<span style="font-family: arial;">posted a notice.</span></span><span style="float:;font-size: 16px;margin-left: 10px;" class="material-icons" onclick="var ci=<?php echo $fetchA['nid'];?>;document.querySelector('#subMenu<?php echo $fetchA['nid'];?>').setAttribute('style','width:70%;height:200px;background:#fff;position: fixed;top:30%;bottom:0;left:50;right:0;box-shadow:1px 1px 8px 01px #000;display:;');">edit</span><span style="float:;font-size: 16px;margin-left: 10px;" class="material-icons" onclick='var confirmAction=confirm("Are you sure to execute this action?");if(confirmAction){window.open("function.php?meth=delete&param="+<?php echo $fetchA["nid"];?>);}else{}'>delete</span><br>
&nbsp;  

<span style="font-family: arial;color:rgba(0,0,0,.7);font-size:14px;">
<?php
$timestamp= $fetchA['date'];
 date_default_timezone_set('Asia/Dhaka');  
// echo facebook_time_ago();  
      $time_ago = strtotime($timestamp);  
      $current_time = time();  
      $time_difference = $current_time - $time_ago;  
      $seconds = $time_difference;  
      $minutes      = round($seconds / 60 );   
      $hours           = round($seconds / 3600); 
      $days          = round($seconds / 86400); 
      $weeks          = round($seconds / 604800);
      $months          = round($seconds / 2629440);    
   
      $years          = round($seconds / 31553280);   
      if($seconds <= 60)  
      {  
     echo "$seconds second ago";  
   }  
      else if($minutes <=60)  
      {  
     if($minutes==1)  
           {  
       echo "1 minute ago";  
     }  
     else  
           {  
       echo "$minutes minutes ago";  
     }  
   }  
      else if($hours <=24)  
      {  
     if($hours==1)  
           {  
       echo "An hour ago";  
     }  
           else  
           {  
       echo "$hours hrs ago";  
     }  
   }  
      else if($days <= 7)  
      {  
     if($days==1)  
           {  
       echo "Yesterday";  
     }  
           else  
           {  
       echo "$days days ago";  
     }  
   }  
      else if($weeks <= 4.3) //4.3 == 52/12  
      {  
     if($weeks==1)  
           {  
       echo "A week ago";  
     }  
           else  
           {  
       echo "$weeks weeks ago";  
     }  
   }  
       else if($months <=12)  
      {  
     if($months==1)  
           {  
       echo "A month ago";  
     }  
           else  
           {  
       echo "$months months ago";  
     }  
   }  
      else  
      {  
     if($years==1)  
           {  
       echo "1 year ago";  
     }  
           else  
           {  
       echo "$years years ago";  
     }  
   }  
?> • <span style="color:rgba(0,0,0,.7);font-size: 14px;" class="material-icons">public</span></span>


  
  </td>
 </tr>
	</table>
		</div>
	<div class="capBar" style="font-family: arial;margin-left: 10px;">
<?php echo $fetchA['caption'];?>
		</div>
	
	<?php
	if($fetchA['photo_link']=='0'){}else{
	?>
	<img style="width:100%;height: auto" src="../photo_of_notice/
<?php echo $fetchA['photo_link'];?>"/>
	
	<?php
	}
	
	?>
<span style="margin-left:10px;font-family:arial;font-weight:300;" id="lc<?php echo $fetchA['nid'];?>">
<?php echo $fetchA['total_likes'];?></span><span style="font-family:arial;font-weight:300;">&nbsp;likes</span><span style="float: right;margin-right:10px;font-family: arial;font-weight:300;">
<?php echo $fetchA['total_shear'];?> shares</span>
		
		<br>
		
		
		<div class="noticeReact">
	<div class="react" onclick="like('<?php echo $fetchA['nid'];?>')">
<table cellspacing="2">
<tr>
<td>
<span class="material-icons" style="font-size: 30px;float: left;margin-left:25px;">favorite_border</span>
</td>
<td>
<span class="reactText">&nbsp;Love</span>
</td>
</tr>
</table>
</div>

<div class="react" onclick="ap('<?php echo $fetchA['nid'];?>');">
<table>
<tr>
<td>
<span class="material-icons" style="font-size: 30px;float: left;margin-left:25px;">share</span>
</td>
<td>
<span class="reactText" >&nbsp;Share</span>
</td>
</tr>
</table>
	</div>
			</div>
	
	
	
	
	

<div class="shear" id="jsPop<?php echo $fetchA['nid'];?>" style="position: fixed;width: 100%;height: 140px;background: #fff;bottom:0;display:none;" >

<input type="text" id="myInp<?php echo $fetchA['nid'];?>" style="color:white;border:none;outline:none;" value="http://rafid.rf.gd/gci/noticeRead.php?id=<?php echo $fetchA['nid'];?>"/>

<span style="font-family: arial;margin-top:10px;margin-left:5px;font-size:20px;font-weight: bold;float:left;">Share to</span><span style="font-size: 30px;float: right;margin-right:10px;" onclick="asp('<?php echo $fetchA['nid'];?>');">&times;</span>

		<div class="icons">
			<table style="font-family: arial;">
			 <tr>
			  <td>
			
<span class="material-icons" style="background: rgba(211,211,211,.6);font-size: 40px;padding:7px;border-radius: 50%;color: rgba(0,0,0,.8);float:left;margin-left:10px;margin-top:10px;" onclick="const myInp=document.getElementById('myInp<?php echo $fetchA['nid'];?>');myInp.select();document.execCommand('Copy');alert('Link Copied');asp('<?php echo $fetchA['nid'];?>');">content_copy</span>
	</td>
	 <td>
<a href="https://www.facebook.com/sharer.php?u=https://localhost:8080/ispahani/noticeRead.php?id=<?php echo $fetchA['nid'];?>"><span style="background: ;font-size: 40px;padding:7px;border-radius: 50%;color: rgba(0,0,0,.8);float:left;margin-left:10px;margin-top:0px;"><img src="../site/f.png" style="height:55px;width:55px;"></span></a>
 </td>
  <td>
<span style="background: ;font-size: 40px;padding:7px;border-radius: 50%;color: rgba(0,0,0,.8);float:left;margin-left:10px;margin-top:0px;"><img src="../site/w.jpeg" style="height:55px;width:100px;"></span>
</td>
 <td>
 <?php
 if($fetchA['photo_link']=='0'){?>
 
 
<span style="background: rgba(211,211,211,.6);font-size: 40px;padding:7px;border-radius: 50%;color: rgba(0,0,0,.8);float:left;margin-left:10px;margin-top:10px;" class="material-icons">file_download_off</span>

 
<?php }else{
?>
<a href="../photo_of_notice/<?php echo $fetchA['photo_link'];?>" download="<?php echo $fetchA['photo_link'];?>"/><span style="background: rgba(211,211,211,.6);font-size: 40px;padding:7px;border-radius: 50%;color: rgba(0,0,0,.8);float:left;margin-left:10px;margin-top:10px;" class="material-icons">file_download</span></a>
<?php }?>
</td>
</tr>
<tr>
<td>
&nbsp;Copy link
</td>
<td>
</td>
<td>
</td>
<td>
 <?php
 if($fetchA['photo_link']=='0'){echo 'Unable ';
}else{

echo 'Save Image';

}?>
</td>
</table>
			</div>
	
	
	
	
	
	
	</div>

	<br>
	<br><br>
	<?php
	}
	?>
	
</body>
<script>

function like(id){
var cur_count=jQuery('#lc'+id).html();
cur_count++;
jQuery('#lc'+id).html(cur_count);
jQuery.ajax({
url:'like.php',
type:'get',
data:'p='+id,
success:function(result){


}

});

}



function auto_grow(element)
{ element.style.height = "55px"; element.style.height = (element.scrollHeight)+"px";
 }
 


 function ap(a){
var b=document.querySelector('#jsPop'+a);
var c=b.getAttribute('style');
if(c=="position: fixed;width: 100%;height: 140px;background: #fff;bottom:0;display:none;"){
b.setAttribute('style','position: fixed;width: 100%;height: 140px;background: #fff;bottom:0;display:;');
}else{
b.setAttribute('style','position: fixed;width: 100%;height: 140px;background: #fff;bottom:0;display:none;');
}
}

function asp(a){
var b=document.querySelector('#jsPop'+a);
var c=b.getAttribute('style');
if(c=="position: fixed;width: 100%;height: 140px;background: #fff;bottom:0;display:;"){
b.setAttribute('style','position: fixed;width: 100%;height: 140px;background: #fff;bottom:0;display:none;');
}
}


</script>
</html>