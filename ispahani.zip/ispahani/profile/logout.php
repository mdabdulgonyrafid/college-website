<?php
include('../php/con.php');
session_start();
mysqli_query($db,"DELETE FROM ip_login WHERE uid='{$_SESSION['uuid']}'");
unset($_SESSION['uuid']);
header('location:../login/');
?>