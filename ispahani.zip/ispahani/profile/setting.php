<?php

include('../php/con.php');
session_start();
$sess=$_SESSION['uuid'];
if($sess){

}else{header('location:../login/');}
$filename="";
 $postid=rand(11111111,99909999);
date_default_timezone_set('Asia/Dhaka');  
$dat=date("Y-m-d H:i:s") ;
       // Getting file name
       if(isset($_FILES['image']['name'])){
       $filename = $_FILES['image']['name'];
         }
       // Valid extension
       $valid_ext = array('png','jpeg','jpg');

			
	   $photoExt1 = @end(explode('.', $filename)); // explode the image name to get the extension
	   $phototest1 = strtolower($photoExt1);
			
	   $new_profle_pic = uniqid("Govt_Ispahani_Collage", true).'.'.$phototest1;
			
       // Location
       $location = "../teachers_profile/".$new_profle_pic;

       // file extension
       $file_extension = pathinfo($location, PATHINFO_EXTENSION);
       $file_extension = strtolower($file_extension);

       // Check extension
       if(in_array($file_extension,$valid_ext)){  

            // Compress Image
            compressedImage($_FILES['image']['tmp_name'],$location,30);
            

			if(isset($_POST['imb'])){





$s=mysqli_query($db,"UPDATE users SET profile='$new_profle_pic' WHERE uid='$sess'");

echo 'Error: ' . mysqli_error($db);
header('location:setting.php');



}


        
    }

    // Compress image
    function compressedImage($source, $path, $quality) {

            $info = getimagesize($source);

            if ($info['mime'] == 'image/jpeg') 
                $image = imagecreatefromjpeg($source);

            elseif ($info['mime'] == 'image/gif') 
                $image = imagecreatefromgif($source);

            elseif ($info['mime'] == 'image/png') 
                $image = imagecreatefrompng($source);

            imagejpeg($image, $path, $quality);

    
}
$fA=mysqli_fetch_array(mysqli_query($db,"SELECT * FROM users WHERE uid='$sess'"));

if(isset($_POST['upName'])){
mysqli_query($db,"UPDATE users SET name='{$_POST['rename']}' WHERE uid='$sess'");

echo 'Error: ' . mysqli_error($db);
header('location:setting.php');
}
$info="";
if(isset($_POST['upPass'])){
$oldpass=$fA['pass'];

if(isset($_POST['newpass'])){
$nPass=$_POST['newpass'];
$oPass=$_POST['oldpass'];
}
if($oldpass==$oPass){
mysqli_query($db,"UPDATE users SET pass='$nPass' WHERE uid='$sess'");

echo 'Error: ' . mysqli_error($db);
header('location:setting.php');
}else{
$info="<script>alert('Old Password is wrong');</script>";
}
}
?>
<html>
<head>
<title>Govt. Ispahani Collage</title>
 <link href="site/l.png" rel="icon">
  <link href="site/l.png" rel="apple-touch-icon">
  <link href = 'https://fonts.googleapis.com/icon?family=Material+Icons' rel = 'stylesheet'>
 <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.css" rel="stylesheet">
<meta name="author" content="Govt Ispahani Collage">
<meta charset="UTF-8">
  <meta name="description" content="Welcome to the Govt Ispahani Collage Website. Stay connected with us for getting notices and more information.">
  <meta name="keywords" content="Collage, Govt Collage, Ispahani Collage, Govt Ispahani Collage">
	<meta name="viewport" content="width=device-width, initial-scale=1 user-scalable=no">
<script src='https://code.jquery.com/jquery-2.1.3.min.js'></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

	<script src="javascript/date.js"></script>
<script src="j.avascript/slider.js"></script>
<style>
body{
margin:0;
padding:0;
}
.nav{
position: fixed;
width:100%;
height:60px;
background: #E0115F;
color: #fff;
top:0;
}

.filelabel .title {
  color: #0693cd;;
}
#FileInput{
    display:none;
}
</style>
<body>

<div class="nav">
<span class="material-icons" style="color:#fff;font-size:35px;float:left;margin-left:5px;margin-top:10px;">arrow_back</span><span style="color: #fff;margin-left:20px;margin-top:17px;float:left;font-family: Senserif;font-weight: 450;"><?php echo $fA['name'];?></span>
</div>
			<br>
			<br>
			<br>
			<h2 style="margin-left:10px">Update Profile</h2>
			<form method="post" enctype="multipart/form-data">
		<div align="center">
		<img style="width:150px;height:150px;border-radius:50%;" src="../teachers_profile/<?php echo $fA['profile'];?>"/>
		<br>
		<div>
		 <label class="filelabel">
		<table style="background:#3b5998;color:#fff;margin:5px;border-radius:5px;font-weight: bold;">
		  <tr>
		   <td>
		  	<span class="material-icons">camera</span>
    <input class="FileUpload1" id="FileInput" name="image" type="file" accept="image/*"/>
	
		</td>
		 <td>
		 Choose a photo
		 
		 </td>
		  </tr>
		   </table>
		   
</label>
<br>
 <input type="submit" style="border:none;background:#E0115F;padding:3px;color: #fff;font-weight:bold;border-radius:5px;" value="Upload" name="imb"/>
		    </div>
		     </form>
		<br>
		<form method="post" action="">
		<input type="text" value="<?php echo $fA['name'];?>" name="rename"/><input type="submit" value="Update" name="upName"/>
		</form>
		</div>
		<br>
		<div>
		<h2 style="margin-left:10px">Update Password</h2>
		<br>
		<?php echo $info;?>
		<br>
		<form action="" method="post">
		<table>
		 <tr>
		  <td>
		  Old Password :
		  </td>
		  <td>
		  <input type="text" name="oldpass"/>
		  </td>
		  </tr>
		   <tr>
		  <td>
		  New Password :
		  </td>
		  <td>
		  <input type="text" name="newpass"/>
		  </td>
		  </tr>
		  </table>
		
		  <br>
		   <input type="submit" style="border:none;background:#3b5998;color: #fff;font-weight:bold;border-radius:5px;padding:03px 0100px 03px 0100px;margin-left:20px;" value="Change Password" name="upPass"/>
		   </form>
		    <br><br>
		  <a style="margin-left: 100px;" href="forget.php" download="a.php">Forgotten password?</a>
		</div>
</body>
</html>