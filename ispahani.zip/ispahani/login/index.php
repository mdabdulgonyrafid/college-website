<?php
include('../php/con.php');
session_start();
$sess="";
if(isset($_SESSION['uuid'])){

echo $sess=$_SESSION['uuid'];
header('location:../profile/');
}
if($sess){
header('location:../profile/');
}



$sessU="";
$sessP="";
if(isset($_POST['user'])){
$sessU=$_POST['user'];
$sessP=$_POST['pass'];
}
$sql=mysqli_query($db,"SELECT * FROM users WHERE phone='$sessU' AND pass='$sessP'");


if(isset($_POST['sub'])){
if(mysqli_num_rows($sql)==1){
$f=mysqli_fetch_array(mysqli_query($db,"SELECT * FROM users WHERE phone='$sessU'"));
$fetchU=$f['uid'];
$_SESSION['uuid']=$fetchU;
mysqli_query($db,"INSERT INTO ip_login(id,uid,ip) VALUES(null,'$fetchU','$ipaddress')");
header('location:../profile/');

}else{
echo '<script>alert(0);</script>';
}

}


?>
<html>
<head>
<title>Login | Govt Ispahani Collage</title>
 <link href="../site/l.png" rel="icon">
  <link href="../site/l.png" rel="apple-touch-icon">
  <link href = 'https://fonts.googleapis.com/icon?family=Material+Icons' rel = 'stylesheet'>
  
<script src='https://code.jquery.com/jquery-2.1.3.min.js'></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
 <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.css" rel="stylesheet">
<meta name="author" content="Govt Ispahani Collage">
<meta charset="UTF-8">
  <meta name="description" content="Welcome to the Govt Ispahani Collage Website. Stay connected with us for getting notices and more information.">
  <meta name="keywords" content="Collage, Govt Collage, Ispahani Collage, Govt Ispahani Collage">
	<meta name="viewport" content="width=device-width, initial-scale=1 user-scalable=no">
	<style>
	body{
	margin:0;
	padding:0;
	font-family: sanserif;
	}
	.header{
	position: fixed;
	width:100%;
	top:0;
	height: 50px;
	background: #E0115F;
	font-family: sanserif;
	color: white;
	font-size: ;
	
	}
	.login{
	padding-top: 60px;

	}
	.loginUser{
	border: 1px solid rgba(0,0,0,.2);
	outline: none;
	font-size: 17px;
	color: rgba(0,0,0,.4);
	
	}
	.material-icons{
	font-size:;
	
	}
	input[type=submit]{
	border:none;
	outline:none;
	padding:02px 0100px 02px 0100px;
	font-size:17px;
	background: #3b5998;
	color: white;
	margin-top:10px;
	border-radius: 5px;
	}
	</style>
	</head>
<body>
	<div class="header" align="center">
	<p> Teachers Door</p>
	</div>
	 
		<div class="login" align="center">
		 <h2>Teacher Login</h2>
		  <form action="" method="POST">
		 <table>
		  <tr>
		   <td>
	<span class="material-icons">smartphone</span>
	</td>
	 <td>
	  <input type="text" name="user" placeholder="Enter Phone Number" id="loginUser" class="loginUser"/>
	   </td>
	    </tr>
	     <tr>
	      <td>
	       
	<span class="material-icons">vpn_key</span> 
	 </td>
	  <td>
	   <input type="password" name="pass" placeholder="Password" id="loginPass" class="loginUser"/>
	    </td>
	     </tr>
	      </table>
	      <input type="submit" value="Log In" name="sub">
	       </form>
		</div>
</body>